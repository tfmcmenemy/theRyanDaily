(function () {
  const lightbox = document.getElementById("lightbox");
  if (!lightbox) return;

  // We allow multiple galleries per page — first one found is used
  const container = document.querySelector(".js-lightbox-gallery");
  if (!container) return;

  const items = Array.from(container.querySelectorAll("[data-lb-src]"));
  if (!items.length) return;

  const data = items.map((el) => ({
    src: el.getAttribute("data-lb-src"),
    title: el.getAttribute("data-lb-title") || "",
    caption: el.getAttribute("data-lb-caption") || "",
    alt: el.querySelector("img")?.alt || "Photo",
  }));

  const imgEl = lightbox.querySelector(".lightbox-img");
  const titleEl = lightbox.querySelector(".lightbox-title");
  const captionEl = lightbox.querySelector(".lightbox-caption");
  const counterEl = lightbox.querySelector(".lightbox-counter");
  const captionBarEl = lightbox.querySelector(".lightbox-captionbar");

  let currentIndex = 0;
  let touchStartX = 0;

  function render() {
    const item = data[currentIndex];

    imgEl.src = item.src;
    imgEl.alt = item.alt;

    titleEl.textContent = item.title;
    captionEl.textContent = item.caption;

    if (counterEl) {
      counterEl.textContent = `${currentIndex + 1} / ${data.length}`;
    }

    const hasText =
      (item.title && item.title.trim()) ||
      (item.caption && item.caption.trim());

    if (captionBarEl) {
      captionBarEl.style.display = hasText ? "block" : "none";
    }
  }

  function openAt(i) {
    currentIndex = i;
    render();
    lightbox.classList.add("is-open");
    lightbox.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function close() {
    lightbox.classList.remove("is-open");
    lightbox.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  function prev() {
    currentIndex = (currentIndex - 1 + data.length) % data.length;
    render();
  }

  function next() {
    currentIndex = (currentIndex + 1) % data.length;
    render();
  }

  // Click any image item -> open
  items.forEach((el, index) => {
    el.addEventListener("click", () => openAt(index));
  });

  // Overlay/buttons using data-action
  lightbox.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-action]");
    const action = btn?.getAttribute("data-action");
    if (!action) return;

    if (action === "close") close();
    if (action === "prev") prev();
    if (action === "next") next();
  });

  // Keyboard support
  document.addEventListener("keydown", (e) => {
    if (!lightbox.classList.contains("is-open")) return;

    if (e.key === "Escape") close();
    if (e.key === "ArrowLeft") prev();
    if (e.key === "ArrowRight") next();
  });

  // Swipe support (on image)
  imgEl.addEventListener("touchstart", (e) => {
    touchStartX = e.touches[0].clientX;
  });

  imgEl.addEventListener("touchend", (e) => {
    const endX = e.changedTouches[0].clientX;
    const dx = endX - touchStartX;

    if (Math.abs(dx) < 50) return;

    if (dx > 0) prev();
    else next();
  });

  // If user arrives via #ask, open the accordion and scroll
  if (location.hash === "#ask") {
    const ask = document.getElementById("ask");
    if (ask && ask.tagName === "DETAILS") {
      ask.open = true;
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          const rect = ask.getBoundingClientRect();
          const target = window.scrollY + rect.bottom + 12;
          const max =
            document.documentElement.scrollHeight - window.innerHeight;
          window.scrollTo({
            top: Math.min(target, max),
            behavior: "smooth",
          });
        });
      });
    }
  }
})();
